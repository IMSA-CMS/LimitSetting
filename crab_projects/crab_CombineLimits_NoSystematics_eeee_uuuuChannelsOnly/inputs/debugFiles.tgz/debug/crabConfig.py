from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.instance = 'prod'
config.General.requestName = 'CombineLimits_NoSystematics_eeee_uuuuChannelsOnly'
config.General.workArea = 'crab_projects'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'PSet.py'
config.JobType.outputFiles = ['testCombine_NoSystematics_eeee_uuuuChannelsOnly.root']
config.JobType.inputFiles = ['datacard_Higgs_Combined.root']
config.JobType.scriptExe = 'runCombineCommands.py'
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.unitsPerJob = 1
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.totalUnits = 1
config.Data.inputDataset = '/Tau/Run2016H-UL2016_MiniAODv2_NanoAODv9-v1/NANOAOD'
config.section_('Site')
config.Site.storageSite = 'T3_US_FNALLPC'
config.section_('User')
config.section_('Debug')
